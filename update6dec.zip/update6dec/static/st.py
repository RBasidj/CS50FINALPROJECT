db.execute("INSERT INTO games (pgn) VALUES :pgn", pgn=pgnexport)
