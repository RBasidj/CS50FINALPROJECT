import os
from stockfish import Stockfish
stockfish = Stockfish(path="/usr/local/python/3.10.4/lib/python3.10/site-packages")